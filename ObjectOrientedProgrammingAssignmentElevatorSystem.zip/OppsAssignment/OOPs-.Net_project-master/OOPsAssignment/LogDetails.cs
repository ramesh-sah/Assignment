﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsAssignment
{
    internal class LogDetails
    {
        private int? id;
        private string dates;
        private string times;
        private string action;

        public LogDetails()
        {
            id = null;
            dates = "";
            times = "";
            action = "";
        }

        public LogDetails(string date, string time, string action, int? id = null)
        {
            this.id = id;
            this.dates = date;
            this.times = time;
            this.action = action;
        }

        public LogDetails(LogDetails logDetails)
        {
            id = logDetails.id;
            dates = logDetails.dates;
            times = logDetails.times;
            action = logDetails.action;
        }

        public int? Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Dates
        {
            get { return dates; }
            set { dates = value; }
        }
        public string Times
        {
            get { return times; }
            set { times = value; }
        }
        public string Action
        {
            get { return action; }
            set { action = value; }
        }

        override
        public string ToString()
        {
            return Id + "," + Dates + ", " + Times + "," + Action;
        }
    }
}