﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace OOPsAssignment
{
    public partial class Form1 : Form
    {
        int x_doorL_close = 200;
        int x_doorL_open = 126;

        int y_liftDown = 462;
        int y_liftUp = 85;

        bool moving_up = false;
        bool moving_down = false;

        String LiftStatus = "GroundFloor";

        public Form1()
        {
            InitializeComponent();
        }

        public void loadcomponent() => InitializeComponent();
        
        public delegate void MethodCall();
        private void updoors_open_Tick(object sender, EventArgs e) // timer event
        {
            if (doorUpLeft.Left >= x_doorL_open && updoorsClosebtn.Enabled != true) // if door is closed
            {
                MethodCall updoor = new MethodCall(updoors_openMethod);
                updoor.Invoke();
            }
            else
            {
                btnDoorOpen.BackColor = Color.White;
                updoorsOpenButtons.Enabled = false;
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "Door open at first floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                timerClose.Enabled = true;
            }
        }

        private void updoors_openMethod() // animate method to open the doors
        {
            doorUpLeft.Left -= 1;
            doorUpRight.Left += 1;
        }

        private void updoors_close_Tick(object sender, EventArgs e) // timer event
        {
            if (doorUpLeft.Left <= x_doorL_close && updoorsOpenButtons.Enabled != true ) // if door is open
            {
                MethodCall updoor = new MethodCall(updoors_closeMethod);
                updoor.Invoke();
            }
            else
            {
                btnCloseDoors.BackColor = Color.White;
                updoorsClosebtn.Enabled = false;
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "Door close at first floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                if (moving_down == true) // if also moving down
                {
                    LiftDislpay.Image = global::OOPsAssignment.Properties.Resources.down;
                    FirstFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.down;
                    GroundFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.down;

                    DownGo.Enabled = true;
                }
            }
        }

        private void updoors_closeMethod() // animate method to close the doors 
        {
            doorUpLeft.Left += 1;
            doorUpRight.Left -= 1;
        }

        private void downdoors_open_Tick(object sender, EventArgs e) // timer event
        {
            if (doorDownLeft.Left >= x_doorL_open && DownDoors_Close.Enabled != true)
            {
                MethodCall downdoor = new MethodCall(downdoors_openMethod);
                downdoor.Invoke();
            }
            else
            {
                btnDoorOpen.BackColor = Color.White;
                DownDoorOpen.Enabled = false;
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "Door open at ground floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                timerClose.Enabled = true;

            }
        }

        private void downdoors_openMethod() // animate method to open down doors
        {
            doorDownLeft.Left -= 1;
            doorDownRight.Left += 1;
        }

        private void downdoors_close_Tick(object sender, EventArgs e) // timer event
        {
            if (doorDownLeft.Left <= x_doorL_close && DownDoorOpen.Enabled != true) // if lift doors are open
            {
                MethodCall downdoor = new MethodCall(downdoors_closeMethod);
                downdoor.Invoke();
            }
            else
            {
                btnCloseDoors.BackColor = Color.White;
                DownDoors_Close.Enabled = false;
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "Door close at ground floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                if (moving_up == true) // if also moving up
                {
                    LiftDislpay.Image = global::OOPsAssignment.Properties.Resources.up;
                    GroundFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.up;
                    FirstFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.up;

                    UpGo.Enabled = true;
                }
            }
        }

        private void downdoors_closeMethod() // animation method to close down doors
        {
            doorDownLeft.Left += 1;
            doorDownRight.Left -= 1;
        }

        private void go_up_Tick(object sender, EventArgs e) // timer event
        {
            if (liftbox.Top != y_liftUp)
            {
                MethodCall movingUp = new MethodCall(liftUp);
                movingUp.Invoke();
            }
            else
            {
                btnFirstFloor.BackColor = Color.White; // changing button color
                requestGroundFloor.BackColor = Color.White; // changing button color
                                                   // inserting into database 
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "Lift at first floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                moving_up = false; // updating moving up status as false
                liftbox.Image = Properties.Resources.inside_life; // changing image resource
                LiftDislpay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay_;
                GroundFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay_;
                FirstFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay_;

                LiftStatus = "FirstFloor"; // updating liftStaus
                UpGo.Enabled = false;
                updoorsOpenButtons.Enabled = true;
            }
        }

        private void liftUp() // method to animate liftbox moving down
        {
            liftbox.Top -= 1;
            liftbox.Image = Properties.Resources.closed_door_without_frame;
        }

        private void go_down_Tick(object sender, EventArgs e) // timer event 
        {
            if (liftbox.Top != y_liftDown) // moving the lift
            {
                MethodCall movingUp = new MethodCall(liftDown);
                movingUp.Invoke();
            }
            else
            {
                btnGroundFloor.BackColor = Color.White;
                requestFirstFloor.BackColor = Color.White;
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();
                string action = "lift at ground floor";
                LogDetails logDetails = new LogDetails(date, time, action);
                bool result = new LogDetailsManager().Insert(logDetails);
                moving_down = false;
                liftbox.Image = Properties.Resources.inside_life;
                LiftDislpay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay; // resource file name Red_firstFloorDisplay = Red_GroundFloorDisplay
                GroundFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay;    // resource file name Red_firstFloorDisplay = Red_GroundFloorDisplay
                FirstFloorDisplay.Image = global::OOPsAssignment.Properties.Resources.Red_firstFloorDisplay;    // resource file name Red_firstFloorDisplay = Red_GroundFloorDisplay

                LiftStatus = "GroundFloor";
                DownGo.Enabled = false;
                DownDoorOpen.Enabled = true;
            }
        }

        private void liftDown() // method to animate liftbox moving up
        {
            liftbox.Top += 1;
            liftbox.Image = Properties.Resources.closed_door_without_frame;
        }

        private void btn_firstFloor_Click(object sender, EventArgs e) // assigning button event 
        {
            if (moving_down == false) // if the lift isnot moving down
            {
                btnFirstFloor.BackColor = Color.Red;
                moving_up = true;
                DownDoors_Close.Enabled = true;
            }
        }

        private void btn_groundFloor_Click(object sender, EventArgs e) // assigning button event 
        {

            if(moving_up == false) // if the lift isnot moving up
            {
                btnGroundFloor.BackColor = Color.Red;
                moving_down = true;
                updoorsClosebtn.Enabled = true;
            }
            
        }

        private void btn_opendoor_Click(object sender, EventArgs e) // assigning button event 
        {
            btnDoorOpen.BackColor = Color.Orange;
            switch (LiftStatus)
            {
                case "GroundFloor":
                    DownDoorOpen.Enabled = true;
                    break;
                case "FirstFloor":
                    updoorsOpenButtons.Enabled = true;
                    break;

            }
        }

        private void btn_closedoors_Click(object sender, EventArgs e) // assigning button event 
        {
            btnCloseDoors.BackColor = Color.Orange;
            switch (LiftStatus)
            {
                case "GroundFloor":
                    DownDoors_Close.Enabled = true;
                    break;
                case "FirstFloor":
                    updoorsClosebtn.Enabled = true;
                    break;
            }
        }

        private void request_F_Click(object sender, EventArgs e) // request first floor event
        {
            if (LiftStatus.Equals("FirstFloor")) // if lift is at first floor
            {
                requestFirstFloor.BackColor = Color.Red; // btn color change
                moving_down = true;
                updoorsClosebtn.Enabled = true;
            }
            
        }

        private void request_G_Click(object sender, EventArgs e)  // request button event
        {
            if (LiftStatus.Equals("GroundFloor")) // if lift is at ground floor
            {
                requestGroundFloor.BackColor = Color.Red; // button color
                moving_up = true;
                DownDoors_Close.Enabled = true;

            }
        }

        private void btn_log_Click(object sender, EventArgs e)  // using delegate
        {
            dataGridViewShowDataLogs.DataSource = null;
        }

       
        

        
        private void Form1_Load(object sender, EventArgs e) // load the data when the form loads
        {
            ArrayList alllogs = new LogDetailsManager().AllLogs();
            dataGridViewShowDataLogs.DataSource = alllogs;
            autoUpdateTimer.Interval = 500; // Set the interval to 5000 milliseconds (5 seconds)
            autoUpdateTimer.Start();
            // Start the timer



        }  

        private void exit_Click(object sender, EventArgs e) // button event
        {
            Application.ExitThread(); // close the software
        }

        private void timer_close_Tick(object sender, EventArgs e)
        {
            switch (LiftStatus)
            {
                case "GroundFloor":
                    DownDoors_Close.Enabled = true;
                    break;
                case "FirstFloor":
                    updoorsClosebtn.Enabled = true;
                    break;
            }
            timerClose.Enabled = false;

        }

        private void autoUpdateTimer_Tick(object sender, EventArgs e)
        {
            RefreshDataGridView();
                
        }
        private void RefreshDataGridView()
        {
            ArrayList alllogs = new LogDetailsManager().AllLogs();
            dataGridViewShowDataLogs.DataSource = null; // Clear the existing data source
            dataGridViewShowDataLogs.DataSource = alllogs; // Set the new data source
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
