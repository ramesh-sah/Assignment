﻿namespace OOPsAssignment
{


    partial class AppData
    {
    }
}

namespace OOPsAssignment.AppDataTableAdapters {
    
    
    public partial class Log_DetailsTableAdapter {
    }
}
