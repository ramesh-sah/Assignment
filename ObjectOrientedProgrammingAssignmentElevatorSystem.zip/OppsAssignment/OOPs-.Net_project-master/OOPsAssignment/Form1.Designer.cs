﻿
namespace OOPsAssignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.updoorsOpenButtons = new System.Windows.Forms.Timer(this.components);
            this.updoorsClosebtn = new System.Windows.Forms.Timer(this.components);
            this.DownDoorOpen = new System.Windows.Forms.Timer(this.components);
            this.DownDoors_Close = new System.Windows.Forms.Timer(this.components);
            this.UpGo = new System.Windows.Forms.Timer(this.components);
            this.DownGo = new System.Windows.Forms.Timer(this.components);
            this.btnLogsDetails = new System.Windows.Forms.Button();
            this.dataGridViewShowDataLogs = new System.Windows.Forms.DataGridView();
            this.GroundFloorDisplay = new System.Windows.Forms.PictureBox();
            this.FirstFloorDisplay = new System.Windows.Forms.PictureBox();
            this.requestFirstFloor = new System.Windows.Forms.Button();
            this.requestGroundFloor = new System.Windows.Forms.Button();
            this.LiftDislpay = new System.Windows.Forms.PictureBox();
            this.BlackPanel = new System.Windows.Forms.PictureBox();
            this.btnDoorOpen = new System.Windows.Forms.Button();
            this.btnCloseDoors = new System.Windows.Forms.Button();
            this.btnGroundFloor = new System.Windows.Forms.Button();
            this.btnFirstFloor = new System.Windows.Forms.Button();
            this.doorDownRight = new System.Windows.Forms.PictureBox();
            this.doorUpRight = new System.Windows.Forms.PictureBox();
            this.doorDownLeft = new System.Windows.Forms.PictureBox();
            this.picBoxsix = new System.Windows.Forms.PictureBox();
            this.doorUpLeft = new System.Windows.Forms.PictureBox();
            this.picBoxSecond = new System.Windows.Forms.PictureBox();
            this.liftbox = new System.Windows.Forms.PictureBox();
            this.picBoxFive = new System.Windows.Forms.PictureBox();
            this.picBoxFirst = new System.Windows.Forms.PictureBox();
            this.picBoxThird = new System.Windows.Forms.PictureBox();
            this.BtnExit = new System.Windows.Forms.Button();
            this.timerClose = new System.Windows.Forms.Timer(this.components);
            this.autoUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.logDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appData = new OOPsAssignment.AppData();
            this.log_DetailsTableAdapter = new OOPsAssignment.AppDataTableAdapters.Log_DetailsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowDataLogs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroundFloorDisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstFloorDisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LiftDislpay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorDownRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorUpRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorDownLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxsix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorUpLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSecond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.liftbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxThird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).BeginInit();
            this.SuspendLayout();
            // 
            // updoorsOpenButtons
            // 
            this.updoorsOpenButtons.Interval = 1;
            this.updoorsOpenButtons.Tick += new System.EventHandler(this.updoors_open_Tick);
            // 
            // updoorsClosebtn
            // 
            this.updoorsClosebtn.Interval = 1;
            this.updoorsClosebtn.Tick += new System.EventHandler(this.updoors_close_Tick);
            // 
            // DownDoorOpen
            // 
            this.DownDoorOpen.Interval = 1;
            this.DownDoorOpen.Tick += new System.EventHandler(this.downdoors_open_Tick);
            // 
            // DownDoors_Close
            // 
            this.DownDoors_Close.Interval = 1;
            this.DownDoors_Close.Tick += new System.EventHandler(this.downdoors_close_Tick);
            // 
            // UpGo
            // 
            this.UpGo.Interval = 1;
            this.UpGo.Tick += new System.EventHandler(this.go_up_Tick);
            // 
            // DownGo
            // 
            this.DownGo.Interval = 1;
            this.DownGo.Tick += new System.EventHandler(this.go_down_Tick);
            // 
            // btnLogsDetails
            // 
            this.btnLogsDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogsDetails.Location = new System.Drawing.Point(680, 73);
            this.btnLogsDetails.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogsDetails.Name = "btnLogsDetails";
            this.btnLogsDetails.Size = new System.Drawing.Size(98, 35);
            this.btnLogsDetails.TabIndex = 16;
            this.btnLogsDetails.Text = "Clear Log";
            this.btnLogsDetails.UseVisualStyleBackColor = true;
            this.btnLogsDetails.Click += new System.EventHandler(this.btn_log_Click);
            // 
            // dataGridViewShowDataLogs
            // 
            this.dataGridViewShowDataLogs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewShowDataLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowDataLogs.Location = new System.Drawing.Point(666, 112);
            this.dataGridViewShowDataLogs.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewShowDataLogs.Name = "dataGridViewShowDataLogs";
            this.dataGridViewShowDataLogs.ReadOnly = true;
            this.dataGridViewShowDataLogs.RowHeadersWidth = 51;
            this.dataGridViewShowDataLogs.RowTemplate.Height = 24;
            this.dataGridViewShowDataLogs.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewShowDataLogs.Size = new System.Drawing.Size(574, 578);
            this.dataGridViewShowDataLogs.TabIndex = 17;
            this.dataGridViewShowDataLogs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // GroundFloorDisplay
            // 
            this.GroundFloorDisplay.BackColor = System.Drawing.SystemColors.Desktop;
            this.GroundFloorDisplay.Location = new System.Drawing.Point(254, 405);
            this.GroundFloorDisplay.Margin = new System.Windows.Forms.Padding(2);
            this.GroundFloorDisplay.Name = "GroundFloorDisplay";
            this.GroundFloorDisplay.Size = new System.Drawing.Size(47, 23);
            this.GroundFloorDisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GroundFloorDisplay.TabIndex = 14;
            this.GroundFloorDisplay.TabStop = false;
            // 
            // FirstFloorDisplay
            // 
            this.FirstFloorDisplay.BackColor = System.Drawing.SystemColors.Desktop;
            this.FirstFloorDisplay.Location = new System.Drawing.Point(254, 28);
            this.FirstFloorDisplay.Margin = new System.Windows.Forms.Padding(2);
            this.FirstFloorDisplay.Name = "FirstFloorDisplay";
            this.FirstFloorDisplay.Size = new System.Drawing.Size(47, 23);
            this.FirstFloorDisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FirstFloorDisplay.TabIndex = 14;
            this.FirstFloorDisplay.TabStop = false;
            // 
            // requestFirstFloor
            // 
            this.requestFirstFloor.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.requestFirstFloor.BackgroundImage = global::OOPsAssignment.Properties.Resources.direction_north;
            this.requestFirstFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.requestFirstFloor.Location = new System.Drawing.Point(387, 583);
            this.requestFirstFloor.Margin = new System.Windows.Forms.Padding(2);
            this.requestFirstFloor.Name = "requestFirstFloor";
            this.requestFirstFloor.Size = new System.Drawing.Size(42, 44);
            this.requestFirstFloor.TabIndex = 13;
            this.requestFirstFloor.UseVisualStyleBackColor = false;
            this.requestFirstFloor.Click += new System.EventHandler(this.request_F_Click);
            // 
            // requestGroundFloor
            // 
            this.requestGroundFloor.BackgroundImage = global::OOPsAssignment.Properties.Resources.direction_south;
            this.requestGroundFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.requestGroundFloor.Location = new System.Drawing.Point(386, 194);
            this.requestGroundFloor.Margin = new System.Windows.Forms.Padding(2);
            this.requestGroundFloor.Name = "requestGroundFloor";
            this.requestGroundFloor.Size = new System.Drawing.Size(43, 44);
            this.requestGroundFloor.TabIndex = 12;
            this.requestGroundFloor.UseVisualStyleBackColor = true;
            this.requestGroundFloor.Click += new System.EventHandler(this.request_G_Click);
            // 
            // LiftDislpay
            // 
            this.LiftDislpay.BackColor = System.Drawing.SystemColors.Desktop;
            this.LiftDislpay.Location = new System.Drawing.Point(505, 220);
            this.LiftDislpay.Margin = new System.Windows.Forms.Padding(2);
            this.LiftDislpay.Name = "LiftDislpay";
            this.LiftDislpay.Size = new System.Drawing.Size(106, 140);
            this.LiftDislpay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LiftDislpay.TabIndex = 11;
            this.LiftDislpay.TabStop = false;
            // 
            // BlackPanel
            // 
            this.BlackPanel.BackColor = System.Drawing.SystemColors.Desktop;
            this.BlackPanel.Location = new System.Drawing.Point(505, 173);
            this.BlackPanel.Margin = new System.Windows.Forms.Padding(2);
            this.BlackPanel.Name = "BlackPanel";
            this.BlackPanel.Size = new System.Drawing.Size(106, 236);
            this.BlackPanel.TabIndex = 10;
            this.BlackPanel.TabStop = false;
            // 
            // btnDoorOpen
            // 
            this.btnDoorOpen.BackgroundImage = global::OOPsAssignment.Properties.Resources.open_door;
            this.btnDoorOpen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDoorOpen.Location = new System.Drawing.Point(581, 573);
            this.btnDoorOpen.Margin = new System.Windows.Forms.Padding(2);
            this.btnDoorOpen.Name = "btnDoorOpen";
            this.btnDoorOpen.Size = new System.Drawing.Size(48, 46);
            this.btnDoorOpen.TabIndex = 7;
            this.btnDoorOpen.UseVisualStyleBackColor = true;
            this.btnDoorOpen.Click += new System.EventHandler(this.btn_opendoor_Click);
            // 
            // btnCloseDoors
            // 
            this.btnCloseDoors.BackgroundImage = global::OOPsAssignment.Properties.Resources.close_door;
            this.btnCloseDoors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCloseDoors.Location = new System.Drawing.Point(491, 573);
            this.btnCloseDoors.Margin = new System.Windows.Forms.Padding(2);
            this.btnCloseDoors.Name = "btnCloseDoors";
            this.btnCloseDoors.Size = new System.Drawing.Size(52, 46);
            this.btnCloseDoors.TabIndex = 6;
            this.btnCloseDoors.UseVisualStyleBackColor = true;
            this.btnCloseDoors.Click += new System.EventHandler(this.btn_closedoors_Click);
            // 
            // btnGroundFloor
            // 
            this.btnGroundFloor.BackgroundImage = global::OOPsAssignment.Properties.Resources.groundFloor;
            this.btnGroundFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnGroundFloor.Location = new System.Drawing.Point(538, 509);
            this.btnGroundFloor.Margin = new System.Windows.Forms.Padding(2);
            this.btnGroundFloor.Name = "btnGroundFloor";
            this.btnGroundFloor.Size = new System.Drawing.Size(44, 46);
            this.btnGroundFloor.TabIndex = 5;
            this.btnGroundFloor.UseVisualStyleBackColor = true;
            this.btnGroundFloor.Click += new System.EventHandler(this.btn_groundFloor_Click);
            // 
            // btnFirstFloor
            // 
            this.btnFirstFloor.AutoSize = true;
            this.btnFirstFloor.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFirstFloor.BackgroundImage = global::OOPsAssignment.Properties.Resources.firstFloor;
            this.btnFirstFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFirstFloor.Location = new System.Drawing.Point(538, 448);
            this.btnFirstFloor.Margin = new System.Windows.Forms.Padding(2);
            this.btnFirstFloor.Name = "btnFirstFloor";
            this.btnFirstFloor.Size = new System.Drawing.Size(44, 46);
            this.btnFirstFloor.TabIndex = 4;
            this.btnFirstFloor.UseVisualStyleBackColor = false;
            this.btnFirstFloor.Click += new System.EventHandler(this.btn_firstFloor_Click);
            // 
            // doorDownRight
            // 
            this.doorDownRight.Image = global::OOPsAssignment.Properties.Resources.door_panel_R;
            this.doorDownRight.Location = new System.Drawing.Point(276, 462);
            this.doorDownRight.Margin = new System.Windows.Forms.Padding(2);
            this.doorDownRight.Name = "doorDownRight";
            this.doorDownRight.Size = new System.Drawing.Size(77, 274);
            this.doorDownRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.doorDownRight.TabIndex = 3;
            this.doorDownRight.TabStop = false;
            // 
            // doorUpRight
            // 
            this.doorUpRight.Image = global::OOPsAssignment.Properties.Resources.door_panel_R;
            this.doorUpRight.Location = new System.Drawing.Point(276, 85);
            this.doorUpRight.Margin = new System.Windows.Forms.Padding(2);
            this.doorUpRight.Name = "doorUpRight";
            this.doorUpRight.Size = new System.Drawing.Size(77, 274);
            this.doorUpRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.doorUpRight.TabIndex = 3;
            this.doorUpRight.TabStop = false;
            // 
            // doorDownLeft
            // 
            this.doorDownLeft.Image = global::OOPsAssignment.Properties.Resources.door_panel;
            this.doorDownLeft.Location = new System.Drawing.Point(201, 462);
            this.doorDownLeft.Margin = new System.Windows.Forms.Padding(2);
            this.doorDownLeft.Name = "doorDownLeft";
            this.doorDownLeft.Size = new System.Drawing.Size(77, 274);
            this.doorDownLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.doorDownLeft.TabIndex = 2;
            this.doorDownLeft.TabStop = false;
            // 
            // picBoxsix
            // 
            this.picBoxsix.Image = global::OOPsAssignment.Properties.Resources.display;
            this.picBoxsix.Location = new System.Drawing.Point(240, 401);
            this.picBoxsix.Margin = new System.Windows.Forms.Padding(2);
            this.picBoxsix.Name = "picBoxsix";
            this.picBoxsix.Size = new System.Drawing.Size(75, 31);
            this.picBoxsix.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxsix.TabIndex = 1;
            this.picBoxsix.TabStop = false;
            // 
            // doorUpLeft
            // 
            this.doorUpLeft.Image = global::OOPsAssignment.Properties.Resources.door_panel;
            this.doorUpLeft.Location = new System.Drawing.Point(201, 85);
            this.doorUpLeft.Margin = new System.Windows.Forms.Padding(2);
            this.doorUpLeft.Name = "doorUpLeft";
            this.doorUpLeft.Size = new System.Drawing.Size(77, 274);
            this.doorUpLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.doorUpLeft.TabIndex = 2;
            this.doorUpLeft.TabStop = false;
            // 
            // picBoxSecond
            // 
            this.picBoxSecond.Image = global::OOPsAssignment.Properties.Resources.display;
            this.picBoxSecond.Location = new System.Drawing.Point(240, 24);
            this.picBoxSecond.Margin = new System.Windows.Forms.Padding(2);
            this.picBoxSecond.Name = "picBoxSecond";
            this.picBoxSecond.Size = new System.Drawing.Size(75, 31);
            this.picBoxSecond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxSecond.TabIndex = 1;
            this.picBoxSecond.TabStop = false;
            // 
            // liftbox
            // 
            this.liftbox.Image = global::OOPsAssignment.Properties.Resources.inside_life;
            this.liftbox.Location = new System.Drawing.Point(201, 462);
            this.liftbox.Margin = new System.Windows.Forms.Padding(2);
            this.liftbox.Name = "liftbox";
            this.liftbox.Size = new System.Drawing.Size(152, 274);
            this.liftbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.liftbox.TabIndex = 8;
            this.liftbox.TabStop = false;
            // 
            // picBoxFive
            // 
            this.picBoxFive.Image = global::OOPsAssignment.Properties.Resources.door_frame;
            this.picBoxFive.Location = new System.Drawing.Point(189, 447);
            this.picBoxFive.Margin = new System.Windows.Forms.Padding(2);
            this.picBoxFive.Name = "picBoxFive";
            this.picBoxFive.Size = new System.Drawing.Size(178, 289);
            this.picBoxFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFive.TabIndex = 0;
            this.picBoxFive.TabStop = false;
            // 
            // picBoxFirst
            // 
            this.picBoxFirst.Image = global::OOPsAssignment.Properties.Resources.door_frame;
            this.picBoxFirst.Location = new System.Drawing.Point(189, 71);
            this.picBoxFirst.Margin = new System.Windows.Forms.Padding(2);
            this.picBoxFirst.Name = "picBoxFirst";
            this.picBoxFirst.Size = new System.Drawing.Size(178, 289);
            this.picBoxFirst.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFirst.TabIndex = 0;
            this.picBoxFirst.TabStop = false;
            // 
            // picBoxThird
            // 
            this.picBoxThird.Image = global::OOPsAssignment.Properties.Resources.button_wall_container;
            this.picBoxThird.Location = new System.Drawing.Point(467, 125);
            this.picBoxThird.Margin = new System.Windows.Forms.Padding(2);
            this.picBoxThird.Name = "picBoxThird";
            this.picBoxThird.Size = new System.Drawing.Size(179, 596);
            this.picBoxThird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxThird.TabIndex = 9;
            this.picBoxThird.TabStop = false;
            // 
            // BtnExit
            // 
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.Location = new System.Drawing.Point(1072, 73);
            this.BtnExit.Margin = new System.Windows.Forms.Padding(2);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(68, 35);
            this.BtnExit.TabIndex = 18;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.exit_Click);
            // 
            // timerClose
            // 
            this.timerClose.Interval = 5000;
            this.timerClose.Tick += new System.EventHandler(this.timer_close_Tick);
            // 
            // autoUpdateTimer
            // 
            this.autoUpdateTimer.Tick += new System.EventHandler(this.autoUpdateTimer_Tick);
            // 
            // logDetailsBindingSource
            // 
            this.logDetailsBindingSource.DataMember = "Log_Details";
            this.logDetailsBindingSource.DataSource = this.appData;
            // 
            // appData
            // 
            this.appData.DataSetName = "AppData";
            this.appData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // log_DetailsTableAdapter
            // 
            this.log_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1251, 749);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.dataGridViewShowDataLogs);
            this.Controls.Add(this.btnLogsDetails);
            this.Controls.Add(this.GroundFloorDisplay);
            this.Controls.Add(this.FirstFloorDisplay);
            this.Controls.Add(this.requestFirstFloor);
            this.Controls.Add(this.requestGroundFloor);
            this.Controls.Add(this.LiftDislpay);
            this.Controls.Add(this.BlackPanel);
            this.Controls.Add(this.btnDoorOpen);
            this.Controls.Add(this.btnCloseDoors);
            this.Controls.Add(this.btnGroundFloor);
            this.Controls.Add(this.btnFirstFloor);
            this.Controls.Add(this.doorDownRight);
            this.Controls.Add(this.doorUpRight);
            this.Controls.Add(this.doorDownLeft);
            this.Controls.Add(this.picBoxsix);
            this.Controls.Add(this.doorUpLeft);
            this.Controls.Add(this.picBoxSecond);
            this.Controls.Add(this.liftbox);
            this.Controls.Add(this.picBoxFive);
            this.Controls.Add(this.picBoxFirst);
            this.Controls.Add(this.picBoxThird);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Elevator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowDataLogs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroundFloorDisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstFloorDisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LiftDislpay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlackPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorDownRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorUpRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorDownLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxsix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doorUpLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSecond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.liftbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxThird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxFirst;
        private System.Windows.Forms.PictureBox picBoxSecond;
        private System.Windows.Forms.PictureBox doorUpLeft;
        private System.Windows.Forms.PictureBox doorUpRight;
        private System.Windows.Forms.PictureBox picBoxFive;
        private System.Windows.Forms.PictureBox picBoxsix;
        private System.Windows.Forms.PictureBox doorDownLeft;
        private System.Windows.Forms.PictureBox doorDownRight;
        private System.Windows.Forms.Button btnFirstFloor;
        private System.Windows.Forms.Button btnGroundFloor;
        private System.Windows.Forms.Button btnCloseDoors;
        private System.Windows.Forms.Button btnDoorOpen;
        private System.Windows.Forms.Timer updoorsOpenButtons;
        private System.Windows.Forms.Timer updoorsClosebtn;
        private System.Windows.Forms.Timer DownDoorOpen;
        private System.Windows.Forms.Timer DownDoors_Close;
        private System.Windows.Forms.Timer UpGo;
        private System.Windows.Forms.Timer DownGo;
        private System.Windows.Forms.PictureBox liftbox;
        private System.Windows.Forms.PictureBox picBoxThird;
        private System.Windows.Forms.PictureBox BlackPanel;
        private System.Windows.Forms.PictureBox LiftDislpay;
        private System.Windows.Forms.Button requestGroundFloor;
        private System.Windows.Forms.Button requestFirstFloor;
        private System.Windows.Forms.PictureBox FirstFloorDisplay;
        private System.Windows.Forms.PictureBox GroundFloorDisplay;
        private System.Windows.Forms.Button btnLogsDetails;
        private System.Windows.Forms.DataGridView dataGridViewShowDataLogs;
        private AppData appData;
        private System.Windows.Forms.BindingSource logDetailsBindingSource;
        private AppDataTableAdapters.Log_DetailsTableAdapter log_DetailsTableAdapter;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Timer timerClose;
        private System.Windows.Forms.Timer autoUpdateTimer;
    }
}

