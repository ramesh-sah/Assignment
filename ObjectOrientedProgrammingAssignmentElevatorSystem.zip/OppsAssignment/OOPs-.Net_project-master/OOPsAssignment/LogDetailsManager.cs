﻿using MySqlConnector;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPsAssignment
{
    internal class LogDetailsManager : MyDatabase
    {
        public bool Insert(LogDetails logDetails)
        {
            string sql = "INSERT INTO elevatorassignment.logdetails(date, time,action) values(@date, @time,@action);";
            bool result = false;
            try
            {

                MySqlConnection conn = Connect();
                MySqlCommand command = new MySqlCommand(sql, conn);
                MySqlParameter[] sqlparams = new MySqlParameter[3];
                sqlparams[0] = new MySqlParameter("@date", logDetails.Dates);
                sqlparams[1] = new MySqlParameter("@time", logDetails.Times);
                sqlparams[2] = new MySqlParameter("@action", logDetails.Action);

                command.Parameters.Add(sqlparams[0]);
                command.Parameters.Add(sqlparams[1]);
                command.Parameters.Add(sqlparams[2]);
                object res = command.ExecuteNonQuery();
                Close(conn);
                result = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                result = false;
            }
            return result;
        }
        public ArrayList AllLogs()
        {
            ArrayList alllogs = new ArrayList();
            try
            {
                string sql = "SELECT * FROM elevatorassignment.logdetails";
                MySqlConnection conn = Connect();
                MySqlCommand command = new MySqlCommand(sql, conn);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    LogDetails logs = new LogDetails();
                    logs.Id = reader.GetInt32("Id");
                    logs.Dates = reader.GetString("Date");
                    logs.Times = reader.GetString("Time");
                    logs.Action = reader.GetString("Action");
                    alllogs.Add(logs);
                }
                Close(conn);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);
            }
            return alllogs;
        }
    }
}
