import React from 'react'

function FreelancerSendApplication() {
  return (
    <div>FreelancerSendApplication</div>
  )
}

export default FreelancerSendApplication