import React from 'react'

function FreelancerUpdateProfile() {
  return (
    <div>FreelancerUpdateProfile</div>
  )
}

export default FreelancerUpdateProfile