import React from 'react'

function FreelancerApproveContract() {
  return (
    <div>FreelancerApproveContract</div>
  )
}

export default FreelancerApproveContract