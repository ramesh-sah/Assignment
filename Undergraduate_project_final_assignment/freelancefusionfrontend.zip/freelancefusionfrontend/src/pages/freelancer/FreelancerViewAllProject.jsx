import React from 'react'

function FreelancerViewAllProject() {
  return (
    <div>FreelancerViewAllProject</div>
  )
}

export default FreelancerViewAllProject