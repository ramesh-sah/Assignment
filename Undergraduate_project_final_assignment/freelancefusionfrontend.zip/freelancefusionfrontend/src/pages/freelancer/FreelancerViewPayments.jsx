import React from 'react'

function FreelancerViewPayments() {
  return (
    <div>FreelancerViewPayments</div>
  )
}

export default FreelancerViewPayments