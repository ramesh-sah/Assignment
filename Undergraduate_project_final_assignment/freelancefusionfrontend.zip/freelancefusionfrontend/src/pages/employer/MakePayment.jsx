import React from 'react'

function MakePayment() {
  return (
    <div>MakePayment</div>
  )
}

export default MakePayment