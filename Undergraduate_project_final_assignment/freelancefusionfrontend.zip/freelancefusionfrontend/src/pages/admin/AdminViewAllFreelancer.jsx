import React from 'react'

function AdminViewAllFreelancer() {
  return (
    <div>AdminViewAllFreelancer</div>
  )
}

export default AdminViewAllFreelancer