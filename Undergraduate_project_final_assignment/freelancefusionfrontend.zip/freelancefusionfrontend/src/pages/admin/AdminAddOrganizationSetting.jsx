import React from 'react'

function AdminAddOrganizationSetting() {
  return (
    <div>AdminAddOrganizationSetting</div>
  )
}

export default AdminAddOrganizationSetting