import React from 'react'

function AdminApprovedContract() {
  return (
    <div>AdminApprovedContract</div>
  )
}

export default AdminApprovedContract