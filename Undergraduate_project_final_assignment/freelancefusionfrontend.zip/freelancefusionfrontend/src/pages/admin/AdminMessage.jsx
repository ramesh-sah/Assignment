import React from 'react'

function AdminMessage() {
  return (
    <div>AdminMessage</div>
  )
}

export default AdminMessage