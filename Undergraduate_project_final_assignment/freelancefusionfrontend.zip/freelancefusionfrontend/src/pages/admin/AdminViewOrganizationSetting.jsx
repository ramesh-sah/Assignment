

function AdminViewOrganizationSetting() {
  return (
    <div>AdminViewOrganizationSetting</div>
  )
}

export default AdminViewOrganizationSetting