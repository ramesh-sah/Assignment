import React from 'react'

function AdminUpdateOwnProfile() {
  return (
    <div>AdminUpdateOwnProfile</div>
  )
}

export default AdminUpdateOwnProfile