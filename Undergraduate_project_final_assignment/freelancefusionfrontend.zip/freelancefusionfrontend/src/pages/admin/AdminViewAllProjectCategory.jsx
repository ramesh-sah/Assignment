
function AdminViewAllProjectCategory() {
  return (
    <div>AdminViewAllProjectCategory</div>
  )
}

export default AdminViewAllProjectCategory