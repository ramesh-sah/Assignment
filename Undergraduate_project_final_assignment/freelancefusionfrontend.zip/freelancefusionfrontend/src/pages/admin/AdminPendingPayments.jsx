import React from 'react'

function AdminPendingPayments() {
  return (
    <div>AdminPendingPayments</div>
  )
}

export default AdminPendingPayments