import React from 'react'

export default function AdminViewAllProject() {
  return (
    <div>AdminViewAllProject</div>
  )
}
