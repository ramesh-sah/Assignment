import React from 'react'

function AdminApprovedPayment() {
  return (
    <div>AdminApprovedPayment</div>
  )
}

export default AdminApprovedPayment