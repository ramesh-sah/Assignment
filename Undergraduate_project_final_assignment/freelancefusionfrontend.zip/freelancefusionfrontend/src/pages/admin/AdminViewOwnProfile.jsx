import React from 'react'

function AdminViewOwnProfile() {
  return (
    <div>AdminViewOwnProfile</div>
  )
}

export default AdminViewOwnProfile