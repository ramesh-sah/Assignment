# freelancefusion
FreelanceFusion is a blockchain-powered freelance platform that integrates smart contracts and automated dispute resolution. This project includes payment integration to ensure seamless financial transactions. Developed as part of a BSc (Hons) Computer Science and Software Engineering undergraduate thesis at the University of Bedfordshire 
