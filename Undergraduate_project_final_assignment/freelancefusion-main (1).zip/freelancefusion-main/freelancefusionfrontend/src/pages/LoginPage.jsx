import Login from "../components/Login"
import LandingPageNavBar from '../components/LandingPageNavBar';


function LoginPage() {
  return (
    <> 
      <LandingPageNavBar />  
   <Login/>
    </>
  )
}

export default LoginPage