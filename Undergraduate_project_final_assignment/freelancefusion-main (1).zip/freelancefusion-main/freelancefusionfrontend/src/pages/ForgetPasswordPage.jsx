import React from 'react'
import ForgetPasswordSection from '../components/ForgetPasswordSection'
import LandingPageNavBar from '../components/LandingPageNavBar';

function ForgetPasswordPage() {
  return (
    <>
     <LandingPageNavBar/>  
      <ForgetPasswordSection />
    </>
   
  )
}

export default ForgetPasswordPage