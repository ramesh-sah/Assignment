import React from 'react'

function FreelancerDashboard() {
  return (
    <div>FreelancerDashboard</div>
  )
}

export default FreelancerDashboard