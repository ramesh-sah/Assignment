import React from 'react'

function FreelancerMessage() {
  return (
    <div>FreelancerMessage</div>
  )
}

export default FreelancerMessage