import React from 'react'

function FreelancerNotification() {
  return (
    <div>FreelancerNotification</div>
  )
}

export default FreelancerNotification