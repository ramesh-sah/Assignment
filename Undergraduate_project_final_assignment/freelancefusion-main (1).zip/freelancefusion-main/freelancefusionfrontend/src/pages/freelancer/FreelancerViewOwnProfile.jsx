import React from 'react'

function FreelancerViewOwnProfile() {
  return (
    <div>FreelancerViewOwnProfile</div>
  )
}

export default FreelancerViewOwnProfile