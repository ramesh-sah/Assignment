import React from 'react'

function EmployerDashboard() {
  return (
    <div>EmployerDashboard</div>
  )
}

export default EmployerDashboard