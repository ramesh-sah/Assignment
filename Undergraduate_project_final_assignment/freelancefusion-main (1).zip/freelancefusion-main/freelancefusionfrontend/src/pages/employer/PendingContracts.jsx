import React from 'react'

function PendingContracts() {
  return (
    <div>PendingContracts</div>
  )
}

export default PendingContracts