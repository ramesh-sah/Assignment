import React from 'react'

function ViewAllContracts() {
  return (
    <div>ViewAllContracts</div>
  )
}

export default ViewAllContracts