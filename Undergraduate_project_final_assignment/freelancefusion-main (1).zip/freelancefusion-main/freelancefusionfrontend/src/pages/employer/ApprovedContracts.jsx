import React from 'react'

function ApprovedContracts() {
  return (
    <div>ApprovedContracts</div>
  )
}

export default ApprovedContracts