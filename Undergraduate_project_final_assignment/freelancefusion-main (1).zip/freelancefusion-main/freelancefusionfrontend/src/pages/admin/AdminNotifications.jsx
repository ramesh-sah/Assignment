import React from 'react'

export default function AdminNotifications() {
  return (
    <div>AdminNotifications</div>
  )
}
