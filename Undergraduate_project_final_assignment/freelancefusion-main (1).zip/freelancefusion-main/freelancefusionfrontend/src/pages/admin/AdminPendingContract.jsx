

function AdminPendingContract() {
  return (
    <div>AdminPendingContract</div>
  )
}

export default AdminPendingContract