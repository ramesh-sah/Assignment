import React from 'react'

export default function AdminViewAllApplications() {
  return (
    <div>AdminViewAllApplications</div>
  )
}
