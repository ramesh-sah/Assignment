import React from 'react'

function AdminReview() {
  return (
    <div>AdminReview</div>
  )
}

export default AdminReview