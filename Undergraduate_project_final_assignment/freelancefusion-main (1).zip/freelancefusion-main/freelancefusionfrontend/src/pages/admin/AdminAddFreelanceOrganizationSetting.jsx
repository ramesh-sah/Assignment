import React from 'react'

function AdminAddFreelanceOrganizationSetting() {
  return (
    <div>AdminAddFreelanceOrganizationSetting</div>
  )
}

export default AdminAddFreelanceOrganizationSetting