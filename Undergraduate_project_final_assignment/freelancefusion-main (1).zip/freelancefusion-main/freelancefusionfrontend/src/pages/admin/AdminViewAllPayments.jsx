import React from 'react'

function AdminViewAllPayments() {
  return (
    <div>AdminViewAllPayments</div>
  )
}

export default AdminViewAllPayments