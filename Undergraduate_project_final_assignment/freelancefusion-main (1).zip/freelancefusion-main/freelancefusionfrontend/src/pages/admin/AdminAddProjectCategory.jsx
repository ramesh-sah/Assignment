import React from 'react'

function AdminAddProjectCategory() {
  return (
    <div>AdminAddProjectCategory</div>
  )
}

export default AdminAddProjectCategory