
function AdminViewAllContract() {
  return (
    <div>AdminViewAllContract</div>
  )
}

export default AdminViewAllContract