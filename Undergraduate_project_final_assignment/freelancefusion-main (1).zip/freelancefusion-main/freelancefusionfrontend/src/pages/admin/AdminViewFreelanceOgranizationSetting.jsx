

function AdminViewFreelanceOgranizationSetting() {
  return (
    <div>AdminViewFreelanceOgranizationSetting</div>
  )
}

export default AdminViewFreelanceOgranizationSetting