import React from 'react'

function AdminAddFreelancer() {
  return (
    <div>AdminAddFreelancer</div>
  )
}

export default AdminAddFreelancer