import React from 'react'
import NotFoundSection from '../components/NotFoundSection'
import LandingPageNavBar from '../components/LandingPageNavBar';

function NotFoundPage() {
  return (
   <>
      <LandingPageNavBar/>
   <NotFoundSection/>
   </>
  )
}

export default NotFoundPage